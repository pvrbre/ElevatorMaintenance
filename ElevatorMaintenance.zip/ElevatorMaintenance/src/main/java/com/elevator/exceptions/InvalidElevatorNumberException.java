package com.elevator.exceptions;

public class InvalidElevatorNumberException extends Exception {
    public InvalidElevatorNumberException(String s) {
        super(s);
    }
}
