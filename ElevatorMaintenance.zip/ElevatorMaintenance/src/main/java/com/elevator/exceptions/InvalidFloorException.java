package com.elevator.exceptions;

public class InvalidFloorException extends Throwable {
    public InvalidFloorException(String s) {
        super(s);
    }
}
